<?php
class JoinAuthor extends ActiveRecord\Model
{
	static $table_name = 'authors';
	static $pk = 'author_id';
};
?>